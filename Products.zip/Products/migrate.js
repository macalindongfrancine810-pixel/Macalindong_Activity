
import { Sequelize } from "sequelize";
import { sequelize } from "./models/db.js";
import "./models/userModel.js";
import "./models/Product.js";
import "./models/Customer.js";
import "./models/Order.js";
import "./models/Supplier.js";
import "./models/Categories.js";
import inquirer from "inquirer";


const rootSequelize = new Sequelize("", "root", "", {
  host: "localhost",
  dialect: "mysql",
  logging: false,
});

try {
  const { createDb } = await inquirer.prompt([
    {
      type: "confirm",
      name: "createDb",
      message: "Database 'Products' may not exist. Create it?",
      default: true,
    },
  ]);

  if (createDb) {
    await rootSequelize.query("CREATE DATABASE IF NOT EXISTS `Products`;");
    console.log("✅ Database created (if it did not exist)");
  }

  await sequelize.authenticate();
  console.log("✅ Connected to MySQL database!");
  await sequelize.sync();
  console.log("✅ Tables created for all models!");
} catch (err) {
  console.error("❌ Migration failed:", err);
  process.exitCode = 1;
} finally {
  await Promise.all([rootSequelize.close(), sequelize.close()]);
}
